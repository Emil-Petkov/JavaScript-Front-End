﻿let number = 10;

do {
    console.log(number);
    number++;
} while (number < 9);
