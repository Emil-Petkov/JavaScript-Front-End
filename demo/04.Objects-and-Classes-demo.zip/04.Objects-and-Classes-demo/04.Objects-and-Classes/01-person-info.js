﻿function solve(firstName, lastName, age) {
    const personInfo = {
        firstName,
        lastName,
        age,
    };

    return personInfo;
}

solve("Peter", 
"Pan",
"20"
)
